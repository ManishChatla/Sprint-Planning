from agents.data_collection_agent import DataCollectionAgent
from agents.analysis_agent import AnalysisAgent
from agents.reporting_agent import ReportingAgent

class Crew:
    def __init__(self):
        self.collector = DataCollectionAgent()
        self.analyzer = AnalysisAgent()
        self.reporter = ReportingAgent()

    def run(self):
        issues = self.collector.run()
        analysis = self.analyzer.run(issues)
        report = self.reporter.run(analysis)
        print(report)