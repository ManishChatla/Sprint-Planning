from jira import JIRA
import os

def fetch_active_sprint_issues():
    jira = JIRA(server=os.getenv("JIRA_SERVER"), basic_auth=(os.getenv("JIRA_USER"), os.getenv("JIRA_TOKEN")))
    jql = f'project = {os.getenv("JIRA_PROJECT")} AND sprint in openSprints()'
    fields = "summary,status,assignee,duedate,labels,customfield_10016"
    issues = jira.search_issues(jql, fields=fields, maxResults=100)
    results = []
    for issue in issues:
        fields = issue.fields
        results.append({
            "key": issue.key,
            "summary": fields.summary,
            "status": fields.status.name,
            "assignee": getattr(fields.assignee, 'displayName', 'Unassigned'),
            "duedate": fields.duedate,
            "labels": fields.labels,
            "story_points": getattr(fields, 'customfield_10016', 0)
        })
    return results