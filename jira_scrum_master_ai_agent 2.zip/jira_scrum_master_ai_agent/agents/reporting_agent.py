class ReportingAgent:
    def run(self, analysis):
        report = "Sprint Report\n"
        report += "\nBlockers:\n" + "\n".join([i['summary'] for i in analysis['blockers']])
        report += "\n\nOverdue Issues:\n" + "\n".join([i['summary'] for i in analysis['overdue']])
        report += "\n\nAssignee Load:\n"
        for person, load in analysis['assignee_load'].items():
            report += f"{person}: {load} points\n"
        return report