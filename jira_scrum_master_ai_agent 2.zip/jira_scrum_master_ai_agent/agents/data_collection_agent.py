from tools.jira_tools import fetch_active_sprint_issues

class DataCollectionAgent:
    def run(self):
        return fetch_active_sprint_issues()