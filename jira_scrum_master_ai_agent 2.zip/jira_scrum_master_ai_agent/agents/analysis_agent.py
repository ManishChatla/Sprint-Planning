class AnalysisAgent:
    def run(self, issues):
        blockers = [i for i in issues if 'Blocked' in i.get('labels', [])]
        overdue = [i for i in issues if i.get('duedate') and i['duedate'] < '2025-07-29']
        assignee_load = {}
        for issue in issues:
            assignee = issue.get('assignee', 'Unassigned')
            points = issue.get('story_points', 0)
            assignee_load[assignee] = assignee_load.get(assignee, 0) + points
        return {"blockers": blockers, "overdue": overdue, "assignee_load": assignee_load}