from crews import Crew

if __name__ == "__main__":
    crew = Crew()
    crew.run()