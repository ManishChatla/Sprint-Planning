
# Jira + LLM Sprint Planner Agent with Subtask Assignment

This agent uses GPT to:
1. Fetch Jira sprint tickets
2. Analyze ticket descriptions
3. Identify required skills
4. Assign to team members
5. If multiple skillsets are needed, split into subtasks and assign accordingly

## 🛠 Setup
- Add `.env` with:
```
OPENAI_API_KEY=your-api-key
```
- Install:
```
pip install -r requirements.txt
```
- Run:
```
python main.py
```

For live Jira usage, use `assign_subtasks()` from `jira_connector.py`.
