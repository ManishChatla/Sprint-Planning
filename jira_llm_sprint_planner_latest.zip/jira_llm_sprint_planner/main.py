
import json
from agent.llm_agent import JiraSprintLLMAgent

# Load tickets (mock or from Jira)
tickets = json.load(open("mock_tickets.json"))
team = json.load(open("data/team.json"))

agent = JiraSprintLLMAgent(tickets, team)
plan = agent.generate_plan()

print("\n📋 Sprint Plan With Subtasks by LLM:")
print(plan)
