import json

def ensure_json(text: str):
    """
    Best-effort JSON parsing for LLM outputs that might include commentary.
    """
    try:
        return json.loads(text)
    except Exception:
        first = text.find('[')
        last = text.rfind(']')
        if first != -1 and last != -1 and last > first:
            return json.loads(text[first:last+1])
        first = text.find('{')
        last = text.rfind('}')
        if first != -1 and last != -1 and last > first:
            return json.loads(text[first:last+1])
        raise
