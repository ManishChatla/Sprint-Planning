import json
from langchain.agents import create_react_agent
from langchain.agents.agent_toolkits import load_mcp_tools
from langchain.chat_models import ChatOpenAI
from src.prompts import HISTORICAL_FETCH, HISTORICAL_ANALYZE, TODOS_FETCH, ENRICH_TODOS, ASSIGNMENT_PLAN, PUSH_ASSIGNMENT
from src.utils import ensure_json

def build_agent():
    llm = ChatOpenAI(model="gpt-4", temperature=0)
    tools = load_mcp_tools()  # Loads Jira MCP tools from your environment
    return create_react_agent(llm=llm, tools=tools)

def _llm():
    return ChatOpenAI(model="gpt-4", temperature=0)

def fetch_history(agent, board_id):
    return agent.invoke(HISTORICAL_FETCH(board_id))

def analyze_history(history_raw):
    res = _llm().predict(HISTORICAL_ANALYZE(history_raw))
    return ensure_json(res)

def fetch_todos(agent, board_id):
    return agent.invoke(TODOS_FETCH(board_id))

def enrich_todos(todos_raw, history):
    res = _llm().predict(ENRICH_TODOS(todos_raw, json.dumps(history, ensure_ascii=False)))
    return ensure_json(res)

def assign_tickets(enriched):
    res = _llm().predict(ASSIGNMENT_PLAN(json.dumps(enriched, ensure_ascii=False)))
    return ensure_json(res)

def push_assignments(agent, assignments):
    for item in assignments:
        key = item.get("key") or item.get("sub_key")
        assignee = item.get("assignee")
        if not key or not assignee or assignee == "Unassigned":
            print(f"⚠️ Skipping {key} (unassigned)")
            continue
        result = agent.invoke(PUSH_ASSIGNMENT(key, assignee))
        print(f"→ Pushed {key} to {assignee}: {result}")
