def HISTORICAL_FETCH(board_id: str) -> str:
    return f"""
Use Jira MCP tools to fetch all tickets that were closed in the last 3 sprints on board '{board_id}'.
For each ticket, return JSON list of objects with: key, summary, description, story_points (if present), assignee.
Return only JSON.
"""


def HISTORICAL_ANALYZE(tickets_json: str) -> str:
    return f"""
You are a sprint planning analyst.

Closed tickets (JSON):
{tickets_json}

For each ticket, infer:
- skills (<=5; e.g., React, Node, SQL, Docker)
- story_points (prefer existing else infer 1/2/3/5/8/13)
- assignee (keep provided name; if missing, "Unassigned")

Return a valid JSON list with: key, summary, skills, story_points, assignee.
"""


def TODOS_FETCH(board_id: str) -> str:
    return f"""
Use Jira MCP tools to fetch all 'To Do' tickets from the latest sprint on board '{board_id}'.
Return a JSON list: key, summary, description.
"""


def ENRICH_TODOS(todos_json: str, history_json: str) -> str:
    return f"""
You are estimating current sprint tickets.

Use historical patterns:
{history_json}

For each current ticket:
{todos_json}

Infer "story_points" (1/2/3/5/8/13) and "skills" (<=5). If a ticket needs multiple distinct domains (UI/API/DB), list all.
Return a valid JSON list: key, summary, skills, story_points.
"""


def ASSIGNMENT_PLAN(enriched_json: str) -> str:
    return f"""
You are an expert sprint planner. Team and capacity (example defaults, edit as needed):

{{
  "Alice": {{"skills": ["React", "UI"], "capacity": 10}},
  "Bob":   {{"skills": ["Node", "API"], "capacity": 13}},
  "Chad":  {{"skills": ["SQL", "DB"], "capacity": 8}}
}}

Assign each ticket in:
{enriched_json}

Rules:
- Match skills; if no single user covers all, split into subtasks per domain.
- Respect remaining capacity (sum of assigned story_points per user must not exceed capacity).
- Prefer past assignees for similar skills when capacity allows.
- If uncertain, set "assignee":"Unassigned".

Return a valid JSON list entries with:
- key (or sub_key for subtasks)
- assignee
- story_points
- skills
- split_into_subtasks (boolean)
- parent (only for subtasks)
"""


def PUSH_ASSIGNMENT(key: str, assignee: str) -> str:
    return f"""
Invoke the Jira MCP assignment tool to assign ticket '{key}' to '{assignee}'.
Confirm success in the tool response. If it fails, provide the error.
"""
