# 🧠 Sprint Planning Agent (LLM + Jira MCP)

Automates sprint planning using LLM + Jira MCP tools (no Jira python library).

- Analyze historical tickets (last 2–3 sprints)
- Infer skills and story points
- Assign tickets by skills & capacity
- Split multi-skill tickets into subtasks
- Push assignments to Jira via MCP tool


## Version 1 – MCP Direct (ReAct)
Agent explicitly calls Jira MCP tools step-by-step.

### Run
```bash
pip install -r requirements.txt
cp .env.example .env
python main.py
```
