import os, json
from dotenv import load_dotenv
from src.agent_flow import build_agent, fetch_history, analyze_history, fetch_todos, enrich_todos, assign_tickets, push_assignments

load_dotenv()

def main():
    agent = build_agent()
    board_id = os.getenv("BOARD_ID")

    history_raw = fetch_history(agent, board_id)
    history = analyze_history(history_raw)

    todos_raw = fetch_todos(agent, board_id)
    enriched = enrich_todos(todos_raw, history)

    assignments = assign_tickets(enriched)
    push_assignments(agent, assignments)

    print(json.dumps(assignments, indent=2))

if __name__ == "__main__":
    main()
